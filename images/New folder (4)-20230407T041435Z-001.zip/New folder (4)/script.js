function first(){
    document.getElementById("slideimage").src="download (3).jpg";
}
function second(){
    document.getElementById("slideimage").src="download (4).jpg";
}
function third(){
    document.getElementById("slideimage").src="download (5).jpg";
}
function fourth(){
    document.getElementById("slideimage").src="images.jpg";
}
// function fifth(){
//     document.getElementById("slideimage").src="download (1).jpg"
// }
setInterval( 1000);
setInterval(second,2000);
setInterval(third,3000);
setInterval(fourth,4000);
// setInterval(fifth,10000);